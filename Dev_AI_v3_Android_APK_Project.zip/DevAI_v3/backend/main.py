from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pathlib import Path
import json
import secrets

app = FastAPI(title="Dev AI Backend", version="3.0")

DATA = Path("backend/data")
DATA.mkdir(parents=True, exist_ok=True)

OWNER_ONLY = True
PUBLIC_ACCESS = False
INTERNET_ACCESS = False

permissions_file = DATA / "permissions.json"
if not permissions_file.exists():
    permissions_file.write_text(json.dumps({
        "internet": False,
        "microphone": False,
        "camera": False,
        "ai_cloud": False,
        "browser": False,
        "file_write": False,
        "code_execution": False
    }, indent=2))

class PermissionRequest(BaseModel):
    action: str
    allowed: bool

class SignalMessage(BaseModel):
    call_id: str
    sender: str
    kind: str
    payload: dict

def load_permissions():
    return json.loads(permissions_file.read_text())

@app.get("/health")
def health():
    return {
        "app": "Dev AI",
        "version": "3.0",
        "owner_only": OWNER_ONLY,
        "public_access": PUBLIC_ACCESS,
        "offline_first": True
    }

@app.get("/permissions")
def permissions():
    return load_permissions()

@app.post("/permissions")
def set_permission(req: PermissionRequest):
    allowed_actions = set(load_permissions())
    if req.action not in allowed_actions:
        raise HTTPException(400, "Unknown permission")
    data = load_permissions()
    data[req.action] = req.allowed
    permissions_file.write_text(json.dumps(data, indent=2))
    return {"action": req.action, "allowed": req.allowed}

@app.post("/call/signal")
def signal(msg: SignalMessage):
    # Production implementation: authenticated WebSocket signaling,
    # short-lived call IDs, replay protection and TLS.
    # This endpoint only carries WebRTC signaling data; it must not
    # receive chat plaintext or private encryption keys.
    return {
        "ok": True,
        "call_id": msg.call_id,
        "kind": msg.kind,
        "server_should_not_decrypt_media": True
    }

@app.post("/owner/session")
def create_owner_session():
    # Placeholder only. Production must use Android/iOS biometric
    # authentication plus a device-bound credential/passkey.
    token = secrets.token_urlsafe(32)
    return {
        "token": token,
        "note": "Replace with real device-bound authentication."
    }
