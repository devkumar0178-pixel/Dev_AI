# Security design

## Identity
Use Android BiometricPrompt / iOS LocalAuthentication.
Do not store fingerprint images/templates in Dev AI.
Biometric success should unlock a device-bound key held by the OS keystore/keychain.

## Chat E2EE
Recommended pattern:
1. Each device has an identity key pair.
2. Establish a session using an audited protocol/library such as Signal Protocol.
3. Encrypt plaintext on the sender device.
4. Server stores/relays ciphertext only.
5. Recipient decrypts locally.
6. Server never receives message keys.

Do NOT write your own cryptographic protocol for production.

## Video calls
Use WebRTC for 1:1 calls. WebRTC media is protected by DTLS-SRTP between peers.
The signaling service exchanges SDP/ICE data and should not receive media plaintext.
For group calls/SFU architecture, add audited WebRTC Insertable Streams / SFrame-style E2EE.

## Local data
Use OS secure storage for keys. Encrypt databases/files at rest.
Separate:
- identity keys
- chat database
- AI memory
- knowledge base
- settings
- audit logs

## Permissions
Every tool should declare:
- permission name
- read/write level
- network requirement
- destructive flag

Default = DENY.
User can allow once, allow while app is open, or always allow.
