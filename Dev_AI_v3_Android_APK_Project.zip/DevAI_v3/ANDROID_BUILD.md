# Android build integration

The original DevAI_v3 starter contains the Python core/backend. The `android/` directory added in
this version is the Android client/build project.

The Android client is intentionally kept separate from the Python backend. The app can check the
backend health, but AI chat, E2EE chat, and WebRTC video are not falsely represented as complete:
those require real model/provider configuration and audited security components.

GitHub Actions is configured at:
`android/.github/workflows/android-apk.yml`
