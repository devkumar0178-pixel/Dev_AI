from dataclasses import dataclass

@dataclass(frozen=True)
class Permission:
    name: str
    description: str
    destructive: bool = False
    needs_network: bool = False

REGISTRY = {
    "internet": Permission("internet", "Access the internet", needs_network=True),
    "camera": Permission("camera", "Use camera"),
    "microphone": Permission("microphone", "Use microphone"),
    "cloud_ai": Permission("cloud_ai", "Send a request to an external AI provider", needs_network=True),
    "browser": Permission("browser", "Navigate websites", needs_network=True),
    "file_write": Permission("file_write", "Create/modify files"),
    "code_execution": Permission("code_execution", "Execute code", destructive=True),
}

class PermissionManager:
    def __init__(self):
        self.state = {name: False for name in REGISTRY}

    def allowed(self, name: str) -> bool:
        return self.state.get(name, False)

    def grant_once(self, name: str):
        if name not in REGISTRY:
            raise ValueError("Unknown permission")
        self.state[name] = True

    def revoke(self, name: str):
        if name in self.state:
            self.state[name] = False

    def require(self, name: str) -> None:
        if not self.allowed(name):
            raise PermissionError(f"Dev approval required: {name}")
