from .config import APP_NAME, OWNER_NAME, VERSION
from .permissions import PermissionManager
from .knowledge import KnowledgeBase
from .plugin import SkillRegistry

class DevAI:
    def __init__(self):
        self.name = APP_NAME
        self.owner = OWNER_NAME
        self.version = VERSION
        self.permissions = PermissionManager()
        self.knowledge = KnowledgeBase()
        self.skills = SkillRegistry()

    def status(self):
        return {
            "name": self.name,
            "owner": self.owner,
            "version": self.version,
            "offline_first": True,
            "public_access": False,
            "skills": self.skills.list()
        }

    def teach(self, topic, content, source="Dev"):
        self.knowledge.teach(topic, content, source)
        return "Knowledge added to Dev AI."

    def ask_local_knowledge(self, query):
        return self.knowledge.search(query)
