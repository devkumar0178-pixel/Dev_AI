class ModelRouter:
    """
    Plug-in point for local models and authorized external AI APIs.
    The router does not bypass authentication, paywalls, or access controls.
    """

    def __init__(self, providers=None):
        self.providers = providers or {}

    def register(self, name, provider):
        self.providers[name] = provider

    def answer(self, prompt, preferred=None):
        names = [preferred] if preferred else list(self.providers)
        for name in names:
            if name in self.providers:
                return self.providers[name].generate(prompt)
        return "No enabled AI model is configured."
