class Skill:
    name = "unnamed"
    description = ""

    def permissions(self):
        return []

    def run(self, context):
        raise NotImplementedError

class SkillRegistry:
    def __init__(self):
        self.skills = {}

    def add(self, skill):
        if skill.name in self.skills:
            raise ValueError("Skill already exists")
        self.skills[skill.name] = skill

    def list(self):
        return [
            {"name": s.name, "description": s.description}
            for s in self.skills.values()
        ]

    def get(self, name):
        return self.skills.get(name)
