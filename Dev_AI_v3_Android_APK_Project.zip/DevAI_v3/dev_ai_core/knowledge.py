import json
from pathlib import Path
from datetime import datetime, timezone

class KnowledgeBase:
    def __init__(self, path="dev_ai_core/data/knowledge.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("[]", encoding="utf-8")

    def _load(self):
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _save(self, data):
        self.path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

    def teach(self, topic, content, source="Dev"):
        data = self._load()
        data.append({
            "id": len(data) + 1,
            "topic": topic,
            "content": content,
            "source": source,
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        self._save(data)

    def search(self, query):
        q = query.lower()
        return [
            item for item in self._load()
            if q in item["topic"].lower() or q in item["content"].lower()
        ]

    def delete(self, item_id):
        data = [x for x in self._load() if x["id"] != item_id]
        self._save(data)
