APP_NAME = "Dev AI"
OWNER_NAME = "Dev"
VERSION = "3.0"

# Security defaults
PUBLIC_ACCESS = False
AUTO_LEARN = False
DEFAULT_PERMISSION = "deny"

# Offline-first
OFFLINE_FIRST = True

# External models must be explicitly enabled by Dev.
MODEL_PROVIDERS = {
    "local": True,
    "cloud": False,
}

FEATURES = {
    "chat": True,
    "video_call": True,
    "voice": True,
    "vision": True,
    "teaching": True,
    "memory": True,
    "web": False,
    "automation": False,
}
