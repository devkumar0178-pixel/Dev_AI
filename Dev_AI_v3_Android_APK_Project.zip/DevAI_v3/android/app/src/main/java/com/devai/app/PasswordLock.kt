package com.devai.app

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object PasswordLock {
    private const val ITERATIONS = 120_000
    private const val KEY_BITS = 256

    fun createHash(password: String): String {
        require(password.length >= 6)
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val hash = derive(password, salt)
        return "v1:${hex(salt)}:${hex(hash)}"
    }

    fun verify(password: String, stored: String): Boolean {
        return try {
            val p = stored.split(":")
            if (p.size != 3 || p[0] != "v1") return false
            val salt = p[1].hexBytes()
            val expected = p[2].hexBytes()
            MessageDigest.isEqual(expected, derive(password, salt))
        } catch (_: Exception) {
            false
        }
    }

    private fun derive(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_BITS)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(spec).encoded
    }

    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it) }

    private fun String.hexBytes(): ByteArray {
        val out = ByteArray(length / 2)
        for (i in out.indices) out[i] = substring(i * 2, i * 2 + 2).toInt(16).toByte()
        return out
    }
}
