package com.devai.app

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var secure: SecurePrefs
    private lateinit var chatText: TextView
    private lateinit var messageInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        secure = SecurePrefs(this)
        showLockIfNeeded()
    }

    private fun showLockIfNeeded() {
        val existing = secure.passwordHash
        if (existing == null) {
            showCreatePassword()
        } else {
            showUnlock()
        }
    }

    private fun showCreatePassword() {
        val input = EditText(this).apply {
            hint = "Create password (6+ characters)"
            inputType = 0x00000081
        }
        AlertDialog.Builder(this)
            .setTitle("Create Dev AI password")
            .setMessage("This password unlocks the app on this device. It is stored only as a derived hash in encrypted app storage.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Create") { _, _ ->
                val p = input.text.toString()
                if (p.length < 6) {
                    showCreatePassword()
                } else {
                    secure.passwordHash = PasswordLock.createHash(p)
                    showApp()
                }
            }
            .show()
    }

    private fun showUnlock() {
        val input = EditText(this).apply {
            hint = "Password"
            inputType = 0x00000081
        }
        AlertDialog.Builder(this)
            .setTitle("Dev AI locked")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Unlock") { _, _ ->
                if (PasswordLock.verify(input.text.toString(), secure.passwordHash!!)) {
                    showApp()
                } else {
                    showUnlock()
                }
            }
            .show()
    }

    private fun showApp() {
        setContentView(R.layout.activity_main)
        chatText = findViewById(R.id.chatText)
        messageInput = findViewById(R.id.messageInput)

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            val msg = messageInput.text.toString().trim()
            if (msg.isEmpty()) return@setOnClickListener
            chatText.append("\n\nYou: $msg\nDev AI: Chat-model integration is not configured yet. Connect your own model/API in the backend before using cloud AI.")
            messageInput.text.clear()
        }

        findViewById<Button>(R.id.healthButton).setOnClickListener {
            chatText.append("\n\nChecking backend…")
            BackendClient(secure.backendUrl).health { result ->
                runOnUiThread { chatText.append("\nBackend: $result") }
            }
        }

        findViewById<Button>(R.id.lockButton).setOnClickListener {
            recreate()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}
