package com.devai.app

import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class BackendClient(private val baseUrl: String) {
    private val executor = Executors.newSingleThreadExecutor()

    fun health(callback: (String) -> Unit) {
        executor.execute {
            val result = try {
                val url = URL("${baseUrl.trimEnd('/')}/health")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                body
            } catch (e: Exception) {
                "Backend unavailable: ${e.message ?: "connection error"}"
            }
            callback(result)
        }
    }
}
