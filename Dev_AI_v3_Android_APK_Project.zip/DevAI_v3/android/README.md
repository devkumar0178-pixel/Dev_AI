# Dev AI v3 — Android APK project

This folder is a buildable Android starter for the existing DevAI_v3 Python backend.

## What is included
- Password lock on first launch (6+ characters).
- Encrypted SharedPreferences protected by Android Keystore.
- Simple Dev AI chat shell.
- Backend `/health` check.
- GitHub Actions workflow that builds a debug APK.
- INTERNET/CAMERA/MICROPHONE permissions declared for future features.

## Important
This is a starter, not a production-certified secure messenger.
The Python backend currently exposes a placeholder owner-session endpoint and does not provide a
real AI model endpoint or production E2EE. Do not treat the app as a secure messenger until:
- device-bound authentication/passkeys or BiometricPrompt are integrated;
- audited Signal-Protocol-compatible E2EE is integrated;
- TLS and certificate validation are enforced;
- WebRTC signaling/authentication is hardened;
- a real AI model adapter is configured;
- secrets are kept out of source control.

## Backend URL
The starter defaults to `http://10.0.2.2:8000`, which is convenient for an Android emulator
talking to a backend running on the host machine. For a physical tablet, use the computer's LAN
address (for example `http://192.168.1.10:8000`) during local development. Production should use
HTTPS.

## Build on GitHub
1. Upload the entire `DevAI_v3` folder to your repository, including `android/`.
2. Open GitHub -> Actions.
3. Select **Build Android APK**.
4. Choose **Run workflow**.
5. When it succeeds, open the workflow run and download the **DevAI-debug-apk** artifact.
