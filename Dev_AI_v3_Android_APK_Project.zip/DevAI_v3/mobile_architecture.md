# Android/iOS app layer

Use a native biometric prompt and WebRTC library in the mobile app.

Suggested screens:
1. Lock Screen — biometric authentication
2. Home — Chat / Voice / Video / Teach / Memory / Tools
3. Chat — encrypted local messages
4. Video — WebRTC 1:1 call
5. Teach — text/PDF/image/audio ingestion
6. Knowledge — search, edit, delete, source metadata
7. Permissions — per-tool Allow Once / Allow While Open / Deny
8. AI Models — local models + explicitly enabled external providers
9. Privacy — keys, backups, network mode, audit log
10. Developer — install/enable skills

For Android, store cryptographic keys in Android Keystore and use BiometricPrompt.
For iOS, use Keychain/Secure Enclave where applicable.

For chat E2EE, integrate an audited Signal-Protocol-compatible library rather than implementing
ratcheting/double-ratchet cryptography yourself.

For video, use WebRTC. Keep signaling separate from media. The signaling server should carry
SDP/ICE metadata only. For production group calls, use an audited E2EE/SFrame-capable design.
