# Dev AI v3 — Private Personal AI

This is a modular starter architecture for a private, owner-controlled AI app.

Core goals:
- Owner-only authentication
- Local/offline-first operation
- Extensible skills/plugins
- Explicit permission gates
- Encrypted local storage
- E2EE chat architecture
- WebRTC 1:1 video-call architecture
- Separate AI/model adapters
- User-controlled knowledge/teaching system

IMPORTANT SECURITY NOTE:
This starter is an architecture/foundation, not a production-certified secure messenger.
For real deployment, use audited cryptographic libraries, secure key storage (Android Keystore/iOS Keychain),
TLS, certificate validation, secure backups, rate limiting, and an audited WebRTC/E2EE implementation.
Do not invent cryptography.

Run backend:
    python -m venv .venv
    # Windows: .venv\\Scripts\\activate
    # Linux/macOS: source .venv/bin/activate
    pip install -r backend/requirements.txt
    uvicorn backend.main:app --reload

The mobile UI should call this backend only for signaling/sync and AI operations that the user has explicitly enabled.
Chat message plaintext should be encrypted on the device before transmission.
